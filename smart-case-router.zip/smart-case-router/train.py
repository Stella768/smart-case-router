"""Train and evaluate the severity classifier, and compare against baselines."""
import json
import joblib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, f1_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline

LEVELS = ["Low", "Medium", "High"]

df = pd.read_csv("cases.csv")
train_df, test_df = train_test_split(
    df, test_size=0.2, stratify=df["severity"], random_state=42
)
test_df.to_csv("test_cases.csv", index=False)

# --- Baselines ---------------------------------------------------------
majority = train_df["severity"].mode()[0]
maj_pred = [majority] * len(test_df)

HIGH_WORDS = ["impersonat", "deepfake", "closed when it is open", "intimidat",
              "officially endorsed", "false voting", "cancelled"]
MED_WORDS = ["paid-for-by", "synthetic", "verification", "misleading",
             "fundraising", "unclear claim"]

def keyword_rule(text):
    t = text.lower()
    if any(w in t for w in HIGH_WORDS):
        return "High"
    if any(w in t for w in MED_WORDS):
        return "Medium"
    return "Low"

rule_pred = [keyword_rule(t) for t in test_df["text"]]

# --- ML model ----------------------------------------------------------
model = Pipeline([
    ("tfidf", TfidfVectorizer(ngram_range=(1, 2), min_df=2, sublinear_tf=True)),
    ("clf", LogisticRegression(max_iter=1000, class_weight="balanced")),
])
model.fit(train_df["text"], train_df["severity"])
pred = model.predict(test_df["text"])
proba = model.predict_proba(test_df["text"])
conf = proba.max(axis=1)

def summarize(name, y_true, y_pred):
    return {
        "model": name,
        "accuracy": round(accuracy_score(y_true, y_pred), 3),
        "macro_f1": round(f1_score(y_true, y_pred, average="macro"), 3),
        "high_recall": round(
            ((np.array(y_pred) == "High") & (np.array(y_true) == "High")).sum()
            / (np.array(y_true) == "High").sum(), 3),
    }

y = test_df["severity"].values
results = [
    summarize("Majority class", y, maj_pred),
    summarize("Keyword rules", y, rule_pred),
    summarize("TF-IDF + Logistic Regression", y, pred),
]
print(pd.DataFrame(results).to_string(index=False))
print()
print(classification_report(y, pred, labels=LEVELS, digits=3))
cm = confusion_matrix(y, pred, labels=LEVELS)
print("Confusion matrix (rows=true, cols=predicted):")
print(pd.DataFrame(cm, index=LEVELS, columns=LEVELS).to_string())

# --- Confidence threshold trade-off (human-in-the-loop) -----------------
rows = []
for th in [0.0, 0.5, 0.6, 0.7, 0.8, 0.9]:
    auto = conf >= th
    cov = auto.mean()
    acc = accuracy_score(y[auto], pred[auto]) if auto.any() else float("nan")
    rows.append({"threshold": th, "auto_routed_share": round(cov, 3),
                 "accuracy_on_auto_routed": round(acc, 3)})
th_df = pd.DataFrame(rows)
print("\nConfidence threshold trade-off:")
print(th_df.to_string(index=False))

fig, ax = plt.subplots(figsize=(6, 4))
ax.plot(th_df["auto_routed_share"], th_df["accuracy_on_auto_routed"], marker="o")
for _, r in th_df.iterrows():
    ax.annotate(f'{r["threshold"]:.1f}', (r["auto_routed_share"], r["accuracy_on_auto_routed"]),
                textcoords="offset points", xytext=(5, 5), fontsize=8)
ax.set_xlabel("Share of cases auto-routed (rest go to human triage)")
ax.set_ylabel("Accuracy on auto-routed cases")
ax.set_title("Confidence threshold: automation vs. accuracy")
ax.grid(alpha=0.3)
fig.tight_layout()
fig.savefig("threshold_tradeoff.png", dpi=150)

joblib.dump(model, "severity_model.joblib")
with open("metrics.json", "w") as f:
    json.dump({"models": results, "thresholds": th_df.to_dict(orient="records")}, f, indent=2)
