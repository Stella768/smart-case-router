"""Stress test: new wordings the model and the rules have never seen.

24 hand-written cases (8 per class) that mean the same as the training
categories but use different words. Small sample: treat as directional only.
"""
import joblib
import pandas as pd
from sklearn.metrics import accuracy_score
from train_rules import keyword_rule

CASES = [
 # High
 ("Ad tells people the election day has been moved to a different date.", "High"),
 ("Video in the ad was digitally altered to show a candidate saying things they never said.", "High"),
 ("Message warns voters they may face trouble if they go to their polling station.", "High"),
 ("Ad pretends to come from the official electoral body and gives wrong voting instructions.", "High"),
 ("Ad says mail-in ballots will no longer be accepted, which is untrue.", "High"),
 ("Advertiser claims election officials publicly backed the candidate, with no proof.", "High"),
 ("The ad says polling stations are shut today though they are open.", "High"),
 ("Ad spreads a fake announcement that the vote is postponed.", "High"),
 # Medium
 ("Ad does not show who paid for it, which is required for political ads.", "Medium"),
 ("Image appears computer-generated but carries no label saying so.", "Medium"),
 ("Advertiser has not finished the steps required to run election ads.", "Medium"),
 ("Headline suggests the ballot proposal does something it does not do.", "Medium"),
 ("Donation request comes from an organization we could not confirm.", "Medium"),
 ("Statement about how the candidate voted in the past is vague and hard to confirm.", "Medium"),
 ("Political ad lacks the sponsor line.", "Medium"),
 ("Ad uses an AI-created voice without informing viewers.", "Medium"),
 # Low
 ("Link to the sponsor information on the landing page does not open.", "Low"),
 ("Company name is spelled with different capital letters in the sponsor line.", "Low"),
 ("Advertiser corrected a spelling error in the disclaimer and sent it again.", "Low"),
 ("Same ad was cleared in another country and is being sent again here.", "Low"),
 ("Sponsor text is there but the font style is inconsistent.", "Low"),
 ("Advertiser changed the website address after the ad was cleared.", "Low"),
 ("Minor spacing issue in the sponsor line.", "Low"),
 ("Typo corrected in the sponsor text and resubmitted for review.", "Low"),
]
df = pd.DataFrame(CASES, columns=["text", "severity"])
model = joblib.load("severity_model.joblib")
df["ml"] = model.predict(df["text"])
df["rules"] = [keyword_rule(t) for t in df["text"]]
print("Unseen-wording test (n=24)")
print("  Keyword rules accuracy:", round(accuracy_score(df.severity, df.rules), 3))
print("  ML model accuracy:     ", round(accuracy_score(df.severity, df.ml), 3))
for lvl in ["High"]:
    m = df.severity == lvl
    print(f"  {lvl} recall - rules: {(df[m].rules==lvl).mean():.2f}, ML: {(df[m].ml==lvl).mean():.2f}")
print()
print(df[(df.ml != df.severity) | (df.rules != df.severity)][["text", "severity", "ml", "rules"]].to_string(index=False))
