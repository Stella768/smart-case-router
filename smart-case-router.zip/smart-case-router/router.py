"""Tenure-aware routing rules (generic, illustrative).

Policy implemented:
  - Pushback (re-opened) cases and High/Medium severity -> tenured agents only.
  - Low severity fresh cases -> newer agents first (a safe place to learn),
    overflowing to tenured agents if no newer agent has capacity.
  - Model confidence below the threshold -> human triage queue.
If no eligible agent has capacity, the case waits in a queue instead of being
sent to someone outside the eligibility rule.
"""
from dataclasses import dataclass, field

TENURED_MONTHS = 6


@dataclass
class Agent:
    agent_id: str
    tenure_months: int
    capacity: int
    assigned: list = field(default_factory=list)

    @property
    def tenured(self):
        return self.tenure_months > TENURED_MONTHS

    def has_capacity(self):
        return len(self.assigned) < self.capacity


def _pick(agents):
    """Least-loaded eligible agent, so work is spread evenly."""
    eligible = [a for a in agents if a.has_capacity()]
    return min(eligible, key=lambda a: len(a.assigned)) if eligible else None


def route(case_type, severity, confidence, agents, threshold=0.7):
    """Return (decision, agent_or_None)."""
    if confidence < threshold:
        return "human_triage", None

    tenured = [a for a in agents if a.tenured]
    newer = [a for a in agents if not a.tenured]

    if case_type == "Pushback" or severity in ("High", "Medium"):
        agent = _pick(tenured)
        return ("assigned_tenured", agent) if agent else ("waiting_for_tenured", None)

    # Fresh + Low
    agent = _pick(newer)
    if agent:
        return "assigned_newer", agent
    agent = _pick(tenured)
    return ("assigned_tenured_overflow", agent) if agent else ("waiting", None)
