"""Try the router on a single case.

Examples:
  python demo.py "Ad tells voters the polling place is closed when it is open."
  python demo.py "Sponsor link on the landing page is broken." --type Fresh
  python demo.py "Disclosure missing on political ad." --type Pushback
"""
import argparse
import joblib
from router import Agent, route

p = argparse.ArgumentParser()
p.add_argument("text")
p.add_argument("--type", choices=["Fresh", "Pushback"], default="Fresh")
p.add_argument("--threshold", type=float, default=0.7)
args = p.parse_args()

model = joblib.load("severity_model.joblib")
proba = model.predict_proba([args.text])[0]
severity = model.classes_[proba.argmax()]
confidence = proba.max()

agents = [Agent("T1", 12, 5), Agent("T2", 9, 5), Agent("N1", 2, 5), Agent("N2", 4, 5)]
decision, agent = route(args.type, severity, confidence, agents, args.threshold)

print(f"Predicted severity : {severity} (confidence {confidence:.2f})")
print(f"Case type          : {args.type}")
print(f"Routing decision   : {decision}" + (f" -> agent {agent.agent_id}" if agent else ""))
for lvl, pr in zip(model.classes_, proba):
    print(f"   P({lvl:<6}) = {pr:.2f}")
