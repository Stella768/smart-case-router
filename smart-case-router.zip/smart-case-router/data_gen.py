"""Generate a synthetic dataset of ad-appeal case descriptions.

All text is invented for this prototype. No real cases, policies, or internal
data are used. The data includes deliberate overlap between classes and some
label noise so results are not artificially perfect.
"""
import random
import pandas as pd

SEED = 42

OPENERS = [
    "Advertiser appeals rejection of an election ad:",
    "Appeal received for a political ad:",
    "Re-review requested for ad:",
    "Advertiser disputes enforcement on ad:",
]

CORE = {
    "High": [
        "the ad impersonates an election authority and gives voters a false voting date",
        "the ad includes a deepfake video of a candidate making a fabricated statement",
        "the ad tells voters a polling place is closed when it is open",
        "the ad claims a candidate was officially endorsed by an election commission without evidence",
        "the ad uses intimidating language aimed at voters near polling locations",
        "the ad falsely states that voting by mail is cancelled",
    ],
    "Medium": [
        "the political ad is missing the required paid-for-by disclosure",
        "the ad uses synthetic media without an AI-generated content label",
        "the advertiser has not completed identity verification for election ads",
        "the headline is misleading about the effect of a ballot measure",
        "the ad promotes political fundraising from an unverified organization",
        "the ad contains an unclear claim about a candidate's voting record",
    ],
    "Low": [
        "the disclosure link on the landing page is broken",
        "the advertiser name in the disclosure has a capitalization mismatch",
        "the advertiser fixed a typo in the disclaimer and resubmitted",
        "the ad was already approved in another region and is resubmitted here",
        "the disclosure text is present but uses inconsistent formatting",
        "the advertiser updated the landing page address after approval",
    ],
}

# Shared filler that appears in every class, so the model cannot rely on it
FILLER = [
    "The advertiser says the ad was reviewed internally before submission.",
    "The ad runs in several regions.",
    "The advertiser asked for a quick decision.",
    "Previous appeal was closed last week.",
    "The creative has been live for several days.",
    "The advertiser contacted support twice.",
]

LEVELS = ["Low", "Medium", "High"]


def make_case(rng, label):
    text = f"{rng.choice(OPENERS)} {rng.choice(CORE[label])}."
    # 15% of cases also mention a phrase from a different class (overlap)
    if rng.random() < 0.15:
        other = rng.choice([l for l in LEVELS if l != label])
        text += f" The advertiser also notes that {rng.choice(CORE[other])}."
    # Add 1-2 filler sentences
    for _ in range(rng.randint(1, 2)):
        text += " " + rng.choice(FILLER)
    return text


def generate(n=3000, label_noise=0.08, pushback_rate=0.25, seed=SEED):
    rng = random.Random(seed)
    rows = []
    weights = [0.40, 0.35, 0.25]  # Low, Medium, High
    for i in range(n):
        true_label = rng.choices(LEVELS, weights)[0]
        text = make_case(rng, true_label)
        # Label noise: reviewers sometimes disagree on borderline cases
        label = true_label
        if rng.random() < label_noise:
            idx = LEVELS.index(true_label)
            neighbours = [j for j in (idx - 1, idx + 1) if 0 <= j < 3]
            label = LEVELS[rng.choice(neighbours)]
        case_type = "Pushback" if rng.random() < pushback_rate else "Fresh"
        rows.append({"case_id": i, "text": text, "severity": label, "case_type": case_type})
    return pd.DataFrame(rows)


if __name__ == "__main__":
    df = generate()
    df.to_csv("cases.csv", index=False)
    print(df.severity.value_counts(normalize=True).round(2).to_string())
    print(df.head(3).to_string())
