"""Compare first-in-first-out assignment with ML-assisted routing.

Uses the held-out test cases (600). Severity "truth" is the dataset label.
Compares how well sensitive cases end up with tenured agents.
Assumptions are simplified and listed in the README.
"""
import copy
import joblib
import pandas as pd
from router import Agent, route

THRESHOLD = 0.7

def make_agents():
    # 10 tenured (12 months) and 8 newer (3 months), 40 cases/day each
    return ([Agent(f"T{i}", 12, 40) for i in range(10)]
            + [Agent(f"N{i}", 3, 40) for i in range(8)])

df = pd.read_csv("test_cases.csv")
model = joblib.load("severity_model.joblib")
proba = model.predict_proba(df["text"])
df["pred"] = model.classes_[proba.argmax(axis=1)]
df["conf"] = proba.max(axis=1)

# "Sensitive" = truly High severity or a pushback (should go to tenured agents)
df["sensitive"] = (df["severity"] == "High") | (df["case_type"] == "Pushback")


def run_fifo():
    """Cases arrive in order; each goes to the next agent with capacity."""
    agents = make_agents()
    out = []
    i = 0
    for _, row in df.iterrows():
        for _ in range(len(agents)):
            a = agents[i % len(agents)]
            i += 1
            if a.has_capacity():
                a.assigned.append(row.case_id)
                out.append(("assigned_tenured" if a.tenured else "assigned_newer"))
                break
        else:
            out.append("waiting")
    return out


def run_ml():
    agents = make_agents()
    out = []
    for _, row in df.iterrows():
        decision, agent = route(row.case_type, row.pred, row.conf, agents, THRESHOLD)
        if agent:
            agent.assigned.append(row.case_id)
        out.append(decision)
    return out


def report(name, decisions):
    d = df.copy()
    d["decision"] = decisions
    sens = d[d.sensitive]
    to_newer = sens.decision.eq("assigned_newer").sum()
    to_tenured = sens.decision.str.startswith("assigned_tenured").sum()
    waiting_or_triage = len(sens) - to_newer - to_tenured
    return {
        "approach": name,
        "sensitive_cases": len(sens),
        "sensitive_sent_to_newer_agents_pct": round(100 * to_newer / len(sens), 1),
        "sensitive_sent_to_tenured_pct": round(100 * to_tenured / len(sens), 1),
        "sensitive_in_human_triage_or_waiting_pct": round(100 * waiting_or_triage / len(sens), 1),
        "all_cases_auto_assigned_pct": round(100 * d.decision.str.startswith("assigned").mean(), 1),
        "all_cases_human_triage_pct": round(100 * d.decision.eq("human_triage").mean(), 1),
    }

res = pd.DataFrame([report("FIFO (baseline)", run_fifo()),
                    report(f"ML-assisted routing (threshold {THRESHOLD})", run_ml())])
print(res.T.to_string(header=False))
res.to_csv("simulation_results.csv", index=False)
