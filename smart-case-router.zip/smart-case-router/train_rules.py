HIGH_WORDS = ["impersonat", "deepfake", "closed when it is open", "intimidat",
              "officially endorsed", "false voting", "cancelled"]
MED_WORDS = ["paid-for-by", "synthetic", "verification", "misleading",
             "fundraising", "unclear claim"]

def keyword_rule(text):
    t = text.lower()
    if any(w in t for w in HIGH_WORDS):
        return "High"
    if any(w in t for w in MED_WORDS):
        return "Medium"
    return "Low"
